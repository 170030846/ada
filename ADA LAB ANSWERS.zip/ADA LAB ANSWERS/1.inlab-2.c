#include<stdio.h>
int main()
{
    char mail[1000];
    int i,j=0,k,c=0,size;
    scanf("%[^\n]", mail );
    char submail[100]="@kluniversity.in";
  for(i=0; mail[i]; i++)
  {
    if(mail[i] == submail[j])
    {
      for(k=i, j=0; mail[k] && submail[j]; j++, k++)
        if(mail[k]!=submail[j])
            break;
       if(!submail[j])
       {
        printf("Substring\n");
        for(size=0;mail[size];size++)
        {
            if(mail[size]==' ')
            break;
            else
            printf("%c",mail[size]);
        }
        printf("\n");
        return 0;
       }
    }
  }
  printf("Not a substring\n");
}