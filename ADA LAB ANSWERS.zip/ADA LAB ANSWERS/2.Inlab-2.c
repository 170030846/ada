#include<stdio.h>
void main()
{
   int n,a[100],i,j,count=0,max=0,b[100],t,t1;
    scanf("%d",&n);
   for(i=0;i<n;i++)
     {
 scanf("%d",&a[i]);
      }
   for(i=0;i<n;i++)
     {
 for(j=1;j<=a[i];j++)
 {
    if(a[i]%j==0)
      {
        count++;
        }
 }
 b[i]=count;
 count=0;
 }

 for(i=0;i<n;i++)
 {
   for(j=0;j<n;j++)
   {
      if(b[i]>b[j])
      {
  t=b[i];
   b[i]=b[j];
   b[j]=t;
   t1=a[i];
   a[i]=a[j];
   a[j]=t1;
   }
   }

       }
       for(i=0;i<n;i++)
       {
  printf("%d ",a[i]);
  }
  }
