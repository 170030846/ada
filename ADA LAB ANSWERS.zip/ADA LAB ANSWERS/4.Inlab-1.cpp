#include <bits/stdc++.h> 
using namespace std; 
#define V 7
int parent[V]; 
int find(int i) 
{ 
  while (parent[i] != i) 
    i = parent[i]; 
  return i; 
} 
void union1(int i, int j) 
{ 
  int a = find(i); 
  int b = find(j); 
  parent[a] = b; 
} 
void kruskalMST(int cost[][V]) 
{ 
  int adjMatrix[V][V];
  for(int i=0;i<V;i++)
    for(int j=0;j<V;j++)
        adjMatrix[i][j]=INT_MAX;
  int mincost = 0; 
  for (int i = 0; i < V; i++) 
    parent[i] = i; 
  int edge_count = 0; 
  while (edge_count < V - 1) { 
    int min = INT_MAX, a = -1, b = -1; 
    for (int i = 0; i < V; i++) { 
      for (int j = 0; j < V; j++) { 
        if (find(i) != find(j) && cost[i][j] < min) { 
          min = cost[i][j]; 
          a = i; 
          b = j; 
        } }  } 

    union1(a, b); 
    adjMatrix[a][b] = min;
    adjMatrix[b][a] = min;
    printf("Edge %d:(%d, %d) cost:%d \n", 
      edge_count++, a, b, min); 
    mincost += min; 
  }// while 
  printf("\n Minimum cost= %d \n", mincost); 
  
  // selecting terminal nodes
  vector<int> terminal;
  for(int i=0;i<V;i++){
      int k = 0;
      for(int j=0;j<V;j++){
          if(adjMatrix[i][j] != INT_MAX)
            k++;
      }
      if(k == 1){
          terminal.push_back(i); }
  }// iterating terminals
  for(int i=0;i<terminal.size();i++){
      for(int j=i+1;j<terminal.size();j++){
          int k;
          for(int l=0;l<V;l++)
            if(adjMatrix[terminal[i]][l] != INT_MAX)
                k = l;
          if(adjMatrix[k][terminal[j]] != INT_MAX){
              cout << "YES";
              return;
          }
      }
  }
  cout << "NO";
}// krushkalMST 
int main() 
{ 
  int cost[][V] = { 
    { INT_MAX,5,1,4,INT_MAX,INT_MAX,INT_MAX}, 
    { 5,INT_MAX,INT_MAX,8,INT_MAX,6,INT_MAX}, 
    { 1,INT_MAX,INT_MAX,3,2,INT_MAX,INT_MAX}, 
    { 4,8,3,INT_MAX,INT_MAX,8,INT_MAX}, 
    { INT_MAX,INT_MAX,2,INT_MAX,INT_MAX,7,9},
    { INT_MAX,6,INT_MAX,8,7,INT_MAX,INT_MAX},
    { INT_MAX,INT_MAX,INT_MAX,INT_MAX,9,INT_MAX,INT_MAX}
  }; 
  kruskalMST(cost); 
 return 0; 
}
