#include <bits/stdc++.h> 
using namespace std; 
int V; 	
int p=0;
// implementation of traveling Salesman Problem 
int travllingSalesmanProblem(int **graph, int s,int **ar) 
{ 
    int i,o,so=s,j,max=0,p=0;int visited[V]={0};
    visited[so]=1;
    for(i=0;i<V;i++){
        int mini=1000;
        for(j=0;j<V;j++){
            if(mini>graph[so][j]&&so!=j&&visited[j]==0){
                    mini=graph[so][j];
                    o=j;
            }
        }
        max+=graph[so][o];
        visited[o]=1;
        ar[so][o]=1;
        ar[o][so]=1;
        so=o;
    }
    max+=graph[so][0];
    ar[so][0]=1;
    ar[0][so]=1;
    return max;
} 
// driver program to test above function 
int main() 
{ int i,j;
    cin>>V;
// matrix representation of graph 
/*int graph[][V] = { { 0, 10, 15, 20 }, 
{ 10, 0, 35, 25 }, 
{ 15, 35, 0, 30 }, 
{ 20, 25, 30, 0 } }; */
int **ar=(int **) malloc(sizeof(int)*(V*V));
for(i=0;i<V;i++){
   ar[i]=(int *) malloc(sizeof(int)*V);
for(j=0;j<V;j++)
ar[i][j]=-1;}
int **g=(int **) malloc(sizeof(int)*(V*V));
// cout<<"xcfhjkl;";
for(i=0;i<V;i++){	
  g[i]=(int *) malloc(sizeof(int)*V);
   for(j=0;j<V;j++){
       cin>>g[i][j];
   }
}
int s = 0,c=0,a,b,d;
int y= travllingSalesmanProblem(g, s,ar);
cin>>a;
while(a--){
 cin>>c>>d;
 if(ar[c][d]!=-1)
 c=1;
}
// cout<<c;
if(c==0){
   cout<<"NO EFFECT\n";
}
else{
   cout<<"IT WILL EFFECT\n";
}
return 0; 
}
