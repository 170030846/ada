#include<bits/stdc++.h>
using namespace std;
struct P
{
    int x,y;
}He[100];
char s[10];
set<int>q1,q2;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        for(int i=1;i<=8;i++)
        {
            cin>>s;
            He[i].x=s[0]-'A'+1;
            He[i].y=s[1]-'0';
            q1.insert(He[i].x);
            q2.insert(He[i].y);
            //cout<<He[i].x<<" "<<He[i].y<<endl;
        }
        if(q1.size()==q2.size()&&q1.size()==8)
        {
            int flag=0;
            for(int i=1;i<=8;i++)
            {
                for(int j=1;j<=8;j++)
                {
                    if(i!=j)
                    {
                        if(abs(He[i].x-He[j].x)==abs(He[i].y-He[j].y))
                           {
                               flag=1;
                               break;
                           }
                    }
                }
            }
            if(flag)
            {
                cout<<"Invalid"<<endl;
            }
            else
            {
                cout<<"Valid"<<endl;
            }
        }
        else
        {
            cout<<"Invalid"<<endl;
        }
       // cout<<q1.size()<<" "<<q2.size()<<endl;
        q1.clear(),q2.clear();
    }
    return 0;
}