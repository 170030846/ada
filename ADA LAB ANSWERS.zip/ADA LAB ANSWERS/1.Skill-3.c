#include<stdio.h>
int main()
{
    int n,q,x,c,a[1000];
    int i,j;
    printf("Enter the size of array and number of queries:\n");
    scanf("%d %d",&n,&q);
    printf("Enter the array elements:\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    printf("Enter the querie values:\n");
    for(j=0;j<q;j++)
    {
        scanf("%d",&x);
        c=x;
        for(i=0;i<n;i++)
        {
          if(c==a[i])
          {
              c=c+1;
          }
        }
        if(c!=x)
        printf("%d",c);
        if(c==x)
        printf("%d",c+1);
    }
}
