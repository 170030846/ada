#include<stdio.h>
int main()
{
    int n,i,j,p,swap,sum=0,a[1000];
    printf("Enter the size of an array:");
    scanf("%d",&n);
    printf("Enter the array elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        p=i;
        for(j=i+1;j<n;j++)
        {
         if ( a[p] > a[j] )
            p = j;
        }
      if ( p != i)
      {
         swap = a[i];
         a[i] = a[p];
         a[p] = swap;
      }
    }
    printf("sorted list is:\n");
    for(i=0;i<n;i++)
    {
        printf("%d\n",a[i]);
        sum=sum+a[i];
    }
    printf("%d",sum);
    }