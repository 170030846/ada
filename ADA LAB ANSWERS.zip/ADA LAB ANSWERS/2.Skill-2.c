#include<stdio.h>
int main()
{
	int a[1000],b[1000],c[1000],k,i,s,h,j;
	for(i=0;i<5;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<5;i++)
	{
		scanf("%d",&b[i]);
	}
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
		{
			if(a[i]-b[j]>0)
			{
			c[i]=a[i]-b[j];
			s=a[i];
			h=b[j];
			}
		}
	}
	for(i=0;i<5;i++)
	{
	if(c[i]>c[i+1] && c[i+1]!=0)
	{
	printf("%d",c[i+1]);
	}
	}
	printf(" That is pair, %d ,%d",s,h);
}
