#include<stdio.h>
int main()
{
int n,i,j,count=0;
printf("Enter the number of bank accounts:\n");
scanf("%d",&n);
int bac[n];
printf("Enter the Type of account:\n");
for(i=1;i<=n;i++)
{
scanf("%d" ,&bac[i]);	
}
for(i=1;i<=n;i++)
{
	for(j=i+1;j<=n;j++)
	{
		if((bac[i]<0&&bac[j]>0)||(bac[i]>0&&bac[j]<0))
		{
			printf("%d %d",bac[i],bac[j]);
			count=count+1;
			printf("\n");
		}	
	}
}
printf("%d",count);
}
