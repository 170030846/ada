 #include<stdio.h>
#include<math.h>
int main()
{
	int n;
	printf("Enter the value of n:\n");
	scanf("%d",&n);
	int a[n],i,j,temp,sum=0,c,d=1;
	printf("Enter the array elements:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(a[i]<a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
	for(i=0;i<n;i++)
	{
		c=pow(2,i);
		sum=sum+c*a[i];
	}
	printf("%d",sum);
}
