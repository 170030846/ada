#include<stdio.h>
int main()
{
    int n,m,i,j,k=0,a[1000],b[1000],c[1000],l,temp;
    printf("Enter the value of n and m:");
    scanf("%d %d",&n,&m);
    printf("Enter the a array elemenst:\n");
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    printf("Enter the b array elemnts:\n");
    for(j=0;j<m;j++)
    scanf("%d",&b[j]);
    for(j=0;j<m;j++)
    {
        for(i=0;i<n;i++)
        {
            if(a[i]==b[j])
            {
            	c[k]=a[i];
            	k++;
            	a[i]=0;
            }
        }
    }
    l=k;
    for(j=0;j<m;j++)
    {
    	for(i=0;i<n;i++)
    	{
    		if(a[i]!=0)
    		{
    			c[k]=a[i];
    			k++;
			}
		}
	}
	for (i =l;i < n;++i)
	{
	for(j = i + 1; j < n;++j)
        {
		if(c[i] > c[j]) 
            {
			temp=c[i];
            c[i] = c[j];
            c[j] = temp;
			}
		}
    }
    for(k=0;k<n;k++)
    printf("%d ",c[k]);
}

