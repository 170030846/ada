#include<stdio.h>
int main()
{
int n,size,i,j,k,c1,c2,c3,s1,s2,s3,pivot;
printf("Enter the value of n:");
scanf("%d",&n);
int a[n],left[n],equal[n],right[n];
printf("Enter the arrray elements:");
for(size=0;size<n;size++)
{
scanf("%d",&a[size]);
}
pivot=a[0];
i=0,c1=0;
j=0,c2=0;
k=0,c3=0;
for(size=1;size<n;size++)
{
if(a[size]<pivot)
{
left[i]=a[size];
i++;
c1=c1+1;
}
else if(a[size]==pivot)
{
equal[j]=a[size];
j++;
c2=c2+1;
}
else if(a[size]>pivot)
{
right[k]=a[size];
k++;
c3=c3+1;
}
} 
for(s1=0;s1<c1;s1++)
printf("%d ",left[s1]);
for(s2=0;s2<c2;s2++)
printf("%d ",equal[s2]);
for(s3=0;s3<c3;s3++)
printf("%d ",right[s3]);
}