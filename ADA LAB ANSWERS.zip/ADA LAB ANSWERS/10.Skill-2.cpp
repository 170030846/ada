#include <iostream>
using namespace std;
 
namespace{
	static const int MAX_VAL = (int) 1E9;
	static const int MIN_VAL = (int) 1E-9;
}
void ArrivaloftheGeneral()
{
	int n, max_i, min_i, max_n = MIN_VAL, min_n = MAX_VAL, a;
	cin>>n;
	for (unsigned i = 0; i < n; i++)
	{
		cin>>a;
		if (a <= min_n)
		{
			min_n = a;
			min_i = i;
		}
		if (a > max_n)
		{
			max_n = a;
			max_i = i;
		}
	}
	cout<<max_i + (n - min_i - 1) - (max_i > min_i);
}