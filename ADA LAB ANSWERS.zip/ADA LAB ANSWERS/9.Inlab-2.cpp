#include <map>
#include <set>
#include <queue>
#include <stack>
#include <vector>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

const double pi = acos(-1.0);
const int inf = 0x3f3f3f3f;
const double eps = 1e-15;
typedef long long LL;
typedef pair <int, int> PLL;

const int N = 100110;
char str[N], p[N];
int pre[N];
int sum[N][26];
int numb[26];

int main()
{
    while (~scanf("%s%s", str, p))
    {
        memset(pre, 0, sizeof(pre));
        memset(sum, 0, sizeof(sum));
        memset(numb, 0, sizeof(numb));
        int n = strlen(str);
        int m = strlen(p);
        if (n < m)
        {
            printf("0\n");
            continue;
        }
        for (int i = 1; i <= n; ++i)
        {
            pre[i] = pre[i - 1];
            if (str[i - 1] == '?')
            {
                ++pre[i];
            }
            for (int j = 0; j < 26; ++j)
            {
                sum[i][j] = sum[i - 1][j];
            }
            if (str[i - 1] >= 'a' && str[i - 1] <= 'z')
            {
                ++sum[i][str[i - 1] - 'a'];
            }
        }
        for (int i = 0; i < m; ++i)
        {
            ++numb[p[i] - 'a'];
        }
        int ans = 0;
        for (int i = 1; i + m - 1 <= n; ++i)
        {
            bool flag = 1;
            int less = 0;
// printf("[%d, %d]\n", i, i + m - 1);
            for (int j = 0; j < 26; ++j)
            {
// printf("p中%c个数%d, str中%c个数%d\n", j + 'a', numb[j], j + 'a', sum[i + m - 1][j] - sum[i - 1][j]);
                if (numb[j] < sum[i + m - 1][j] - sum[i - 1][j])
                {
                    flag = 0;
                    break;
                }
                else if (numb[j] > sum[i + m - 1][j] - sum[i - 1][j])
                {
                    less += numb[j] - (sum[i + m - 1][j] - sum[i - 1][j]);
                }
            }
// printf("less = %d, flag = %d\n", less, flag);
            if (flag && pre[i + m - 1] - pre[i - 1] == less)
            {
                ++ans;
            }
        }
        printf("%d\n", ans);
    }
    return 0;
}