#include <stdio.h>
#include <stdlib.h>
void swap(int *a, int *b) 
{
int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}
void quickSort(int arr[], int lowPos, int highPos)
{
int low_Pos = lowPos; 
int high_Pos = highPos; 
int * arr_ptr = (int*) arr;
int pivot = *(arr_ptr + ((low_Pos + high_Pos) / 2));
do {
while (*(arr_ptr + low_Pos) < pivot) low_Pos++; 
while (*(arr_ptr + high_Pos) > pivot) high_Pos--; 
if (low_Pos <= high_Pos) 
{
swap((arr_ptr + low_Pos), (arr_ptr + high_Pos));
        low_Pos++;
        high_Pos--;
}
    } 
while (low_Pos <= high_Pos);
if (lowPos < high_Pos)
quickSort(arr, lowPos, high_Pos);
if (low_Pos < highPos)
quickSort(arr, low_Pos, highPos);
}
int main() 
{
int N;
scanf("%d",&N);
int arr[N][N];
int *arr_ptr = arr;
int row, column;
for (row = 0; row < N; row++) 
{
for (column = 0; column < N; column++) 
{
    scanf("%d",&arr[row][column]);
}
}
printf("The array before sorting :\n");
for (row = 0; row < N; row++) 
{
for (column = 0; column < N; column++)
{
printf("%3d", arr[row][column]);
}
printf("\n");
}
quickSort(arr_ptr, 0, (N * N) - 1);
printf("\nThe array after sorting :\n");
for (int row = 0; row < N; row++) {
for (int column = 0; column < N; column++) 
{
printf("%3d", arr[row][column]);
}
printf("\n");
}
}