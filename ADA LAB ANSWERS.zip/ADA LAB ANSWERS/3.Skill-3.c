#include<stdio.h>
#include<math.h>
int main()
{
	int n;
	printf("Enter the value of n:\n");
	scanf("%d",&n);
	int a[n],i,j,temp,sum=0,c,d=1;
	printf("Enter the array elements:\n");
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=1;i<=n;i++)
	{
		for(j=i+1;j<=n;j++)
		{
			if(a[i]>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
	for(i=n;i>=1;i--)
	{
		c=pow(n,i);
		sum=sum+c*a[d];
		d++;
	}
	printf("%d ",sum);
}
