xw#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define f(i, x, n) for (int i = x; i < (int)(n); ++i)

int const N = 50000, B = 16, X = 500000;
int sp[N + 1][B], spb[N + 1], x[N + 1], n, mnp[X + 1];
ll an, pr[N + 1], sf[N + 2];

int gcd(int a, int b) { return b ? gcd(b, a % b) : a; }
inline int gc(int l, int r){
	int b = spb[r - l + 1];
	return gcd(sp[l][b], sp[r - (1 << b) + 1][b]);
}

void calcPr(){
	int j = 1;
	f(i, 1, n + 1){
		while (j <= i && gc(j, i) == 1)++j;
		pr[i] = pr[i - 1] + i - j + 1;
	}
}

void calcSf(){
	int j = n;
	for (int i = n; i > 0; --i){
		while (j >= i && gc(i, j) == 1)--j;
		sf[i] = sf[i + 1] + j - i + 1;
	}
}

vector<pair<int, int> > Jl(int id){
	vector<pair<int, int> > an(1, make_pair(0, 1));
	int j = id, g = x[id - 1];
	while (an.back().first != 1 && j > 1){
		int l = 1, r = j - 1, c = gcd(g, x[r]);
		while (r > l){
			int m = r + l >> 1;
			if (gc(m, id - 1) != c)l = m + 1;
			else r = m;
		}
		an.push_back(make_pair(c, j - l));
		j = l;
		g = c;
	}
if (an.back().first == 1)an.pop_back();
	return an;
}

vector<pair<int, int> > Jr(int id){
	vector<pair<int, int> > an(1, make_pair(0, 1));
	int j = id, g = x[id + 1];
	while (an.back().first != 1 && j < n){
		int l = j + 1, r = n, c = gcd(g, x[l]);
		while (r > l){
			int m = r + l + 1 >> 1;
			if (gc(id + 1, m) != c)r = m - 1;
			else l = m;
		}
		an.push_back(make_pair(c, l - j));
		j = l;
		g = c;
	}
	if (an.back().first == 1)an.pop_back();
	return an;
}

inline ll goan(vector<pair<int, int> > const &l, vector<pair<int, int> > const &r, int ls, int rs){
	ll an = 0;
	f(i, 0, ls)f(j, 0, rs)if (gcd(l[i].first, r[j].first) != 1)an += (ll)l[i].second * r[j].second;
	return an;
}

ll go(int id){
	vector<pair<int, int> > l = Jl(id), r = Jr(id);
	int z = l.size() - 1, y = r.size() - 1;
	while ((ll)mnp[l[z].first] * mnp[r.back().first] > X)--z;
	while ((ll)mnp[l.back().first] * mnp[r[y].first] > X)--y;
	return max(goan(l, r, z + 1, r.size()), goan(l, r, l.size(), y + 1));
}

int main(){
	mnp[0] = 1;
	f(i, 2, X + 1)for (int j = i; j <= X; j += i)if (mnp[j] == 0)mnp[j] = i;
	scanf("%d", &n);
	f(i, 1, n + 1)scanf("%d", x + i);
	f(i, 1, n + 1)sp[i][0] = x[i];
	f(b, 1, B)f(j, 1, n + 1){
int k = j + (1 << b - 1);
		if (k > n)break;
		sp[j][b] = gcd(sp[j][b - 1], sp[k][b - 1]);
	}
	int z = -1;
	f(i, 1, n + 1){
		if (i == (i & -i))++z;
		spb[i] = z;
	}
	
	calcPr();
	calcSf();
	
	an = pr[n];
	f(i, 1, n + 1)an = max(an, go(i) + pr[i - 1] + sf[i + 1]);
	
	printf("%lld\n", an);
}