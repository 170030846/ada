#include<stdio.h>
int main()
{
	int n,i,j,k,temp,a[1000];
	printf("Enter the Kth box to find:");
	scanf("%d",&k);
	printf("Enter the number of boxes:");
	scanf("%d",&n);
	printf("Ener the array elements:");
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=1;i<=n;i++)
	{
		for(j=i+1;j<=n;j++)
		{
			if(a[i]>a[j])
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
	for(i=1;i<=n;i++)
	{
		if(k==a[i])
		{
			printf("Kth smallest box is:%d ",i);
		}
	}
}
