#include<stdio.h>
int main()
{
	int n,i,result;
	scanf("%d ",&n);
	int a[n],diff,c=0,d=0,count1=0,count2=0;
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=1;i<=n-1;i++)
	{
		diff=a[i+1]-a[i];
		if(diff==1)
		c=c+1;
		else
		d=d+1;
   }
   printf("%d %d\n",c,d);
   if(c==n-1&&d==0)
   {
   	count1=count1+1;
   	printf("%d",count1);
   }
   if((d==n-1&&c==0)||(c%2==0&&d!=0))
   {
   	printf("%d",d+1);
   }
   if(c%2!=0&&d%2!=0)
   printf("%d",c+d);
}
